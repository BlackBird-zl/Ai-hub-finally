# 🤖 AI Hub — Robozinho Flutuante

Overlay Android que fica 24/7 na tela com acesso rápido às suas IAs favoritas, com opção de tirar print e enviar direto para elas.

## Apps incluídos
- 🤖 Claude (Anthropic)
- 🧠 ChatGPT (OpenAI)
- 🌙 Kimi (Moonshot AI)
- ⬛ Blackbox AI
- ✨ Gemini (Google)

## Como gerar o APK

1. Vá em **Actions → Build APK → Run workflow**
2. Aguarde ~3-5 minutos
3. Baixe o **AI-Hub.apk** em Artifacts

## Como instalar

- Transfira o APK para o celular
- Habilite **Instalar apps desconhecidos** nas configurações
- Instale e conceda permissão de **Exibir sobre outros apps**
